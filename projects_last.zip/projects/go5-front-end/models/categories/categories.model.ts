
export class CategoriesModel {
  id?:string;
  name?:string
  urlHandle?:string
}
