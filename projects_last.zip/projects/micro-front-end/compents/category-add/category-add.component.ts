import { Component } from '@angular/core';

@Component({
  selector: 'app-category-add',
  standalone: true,
  imports: [],
  templateUrl: './category-add.component.html',
  styleUrl: './category-add.component.scss'
})
export class CategoryAddComponent {

}
