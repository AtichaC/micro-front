import { Component } from '@angular/core';
import { CategoriesService } from '../../services/categories.service';

@Component({
  selector: 'app-categories',
  standalone: true,
  imports: [],
  templateUrl: './categories.component.html',
  styleUrl: './categories.component.scss'
})
export class CategoriesComponent {
  constructor(private categoriesService: CategoriesService){

  }
  ngOnInit(){
    this.categoriesService.getCategories().subscribe((result)=>{
      console.log(result)
    })
  }
}
